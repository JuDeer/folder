######################
# addonvar.py
######################
import xbmc, xbmcvfs, xbmcaddon, xbmcgui, os

# ---------------------------------------------------------
# ADDON INFO
# ---------------------------------------------------------
addon          = xbmcaddon.Addon()
addon_id       = addon.getAddonInfo("id")
addon_name     = addon.getAddonInfo("name")
addon_version  = addon.getAddonInfo("version")
addon_icon     = addon.getAddonInfo("icon")
addon_fanart   = addon.getAddonInfo("fanart")

addon_path     = xbmcvfs.translatePath(addon.getAddonInfo("path"))
addon_profile  = xbmcvfs.translatePath(addon.getAddonInfo("profile"))

# ---------------------------------------------------------
# BUILD FILE URL
# ---------------------------------------------------------
buildfile = "https://raw.githubusercontent.com/JuDeer/folder/master/logo/links.xml"

# ---------------------------------------------------------
# UNIVERSAL PATHS (Portable + Standard Kodi)
# ---------------------------------------------------------

# Base Kodi folders
home      = xbmcvfs.translatePath("special://home/")
userdata  = xbmcvfs.translatePath("special://userdata/")

# Detect addons path:
# Portable Kodi → special://home/portable_data/addons/
# Normal Kodi   → special://home/addons/
portable_addons = os.path.join(home, "portable_data", "addons")
normal_addons   = os.path.join(home, "addons")

if os.path.exists(portable_addons):
    addons_path = portable_addons
else:
    addons_path = normal_addons

# Packages folder (inside the chosen addons folder)
packages = os.path.join(addons_path, "packages")

# Make sure packages folder exists (prevent errors)
if not os.path.exists(packages):
    try:
        os.makedirs(packages, exist_ok=True)
    except:
        pass

# Wizard addon data folder
data_path = os.path.join(userdata, "addon_data", addon_id)

# Temporary ZIP download
zippath = os.path.join(packages, "tempzip.zip")

# ---------------------------------------------------------
# DIALOGS
# ---------------------------------------------------------
dialog = xbmcgui.Dialog()
dp     = xbmcgui.DialogProgress()

# ---------------------------------------------------------
# SETTINGS HELPERS
# ---------------------------------------------------------
def setting(key):
    try:
        return addon.getSetting(key)
    except:
        return ""

def setting_set(key, value):
    try:
        addon.setSetting(key, value)
    except:
        pass

local_string = addon.getLocalizedString

# ---------------------------------------------------------
# HEADERS
# ---------------------------------------------------------
user_agent = "Mozilla/5.0 (JuDeerKodiWizard)"
headers = {"User-Agent": user_agent}

# ---------------------------------------------------------
# SYSTEM INFO
# ---------------------------------------------------------
try:
    KODIV = float(xbmc.getInfoLabel("System.BuildVersion")[:4])
except:
    KODIV = 0.0

sleep = xbmc.sleep