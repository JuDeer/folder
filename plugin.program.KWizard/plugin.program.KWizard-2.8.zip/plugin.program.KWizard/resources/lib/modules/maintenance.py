######################
# maintenance.py
######################
import os, shutil, xbmc, xbmcgui, xbmcvfs

from addonvar import addon_name, addon_id, userdata, addons_path, packages, local_string

############################################
# CLEAR CACHE
############################################
def clear_cache():
    cache_dirs = [
        os.path.join(userdata, 'cache'),
        os.path.join(userdata, 'temp'),
        os.path.join(userdata, 'addon_data', 'temp'),
    ]

    for cdir in cache_dirs:
        if os.path.exists(cdir):
            shutil.rmtree(cdir, ignore_errors=True)

    xbmc.log("[Wizard] Cache cleared.", xbmc.LOGINFO)

############################################
# CLEAR TEMP FILES
############################################
def clear_temp():
    temp_dirs = [
        os.path.join(userdata, "temp"),
        os.path.join(userdata, "cache"),
    ]

    for tdir in temp_dirs:
        if os.path.exists(tdir):
            shutil.rmtree(tdir, ignore_errors=True)

    xbmc.log("[Wizard] Temp files cleared.", xbmc.LOGINFO)

############################################
# CLEAR PACKAGES
############################################
def clear_packages():
    if not os.path.exists(packages):
        return

    for filename in os.listdir(packages):
        file_path = os.path.join(packages, filename)
        if os.path.isfile(file_path) or os.path.islink(file_path):
            os.unlink(file_path)
        else:
            shutil.rmtree(file_path, ignore_errors=True)

    xbmc.log("[Wizard] Packages cleared.", xbmc.LOGINFO)

############################################
# FULL CLEAN
############################################
def full_clean():
    dp = xbmcgui.DialogProgress()
    dp.create(addon_name, "Running full clean...")

    dp.update(10, "Clearing cache...")
    clear_cache()

    dp.update(40, "Clearing temp folders...")
    clear_temp()

    dp.update(80, "Removing packages...")
    clear_packages()

    dp.update(100, "Full clean complete!")
    dp.close()

    xbmcgui.Dialog().ok(addon_name, "Full system clean completed.")

############################################
# FRESH START (COMPLETE WIPE)
############################################
def fresh_start():
    yes = xbmcgui.Dialog().yesno(
        "Factory Reset",
        "[COLOR red][B]WARNING:[/B][/COLOR] This will reset Kodi to factory defaults.\n\n"
        "Continue?",
        yeslabel="Yes",
        nolabel="No"
    )

    if not yes:
        return

    dp = xbmcgui.DialogProgress()
    dp.create(addon_name, "Performing Fresh Start...")


    # NOTHING TO KEEP EXCEPT THE WIZARD
    KEEP_ADDONS = [addon_id]   # Wizard folder ONLY
    KEEP_FOLDERS = ["addon_data"]


    #########################################
    # PHASE 1 – Delete all files in userdata
    #########################################
    dp.update(25, "Removing userdata files...")
    for root, dirs, files in os.walk(userdata):
        for f in files:
            try:
                os.remove(os.path.join(root, f))
            except:
                pass


    #########################################
    # PHASE 2 – Remove userdata folders except addon_data
    #########################################
    dp.update(55, "Cleaning userdata folders...")
    for item in os.listdir(userdata):
        if item not in KEEP_FOLDERS:
            shutil.rmtree(os.path.join(userdata, item), ignore_errors=True)


    #########################################
    # PHASE 3 – Clean addons folder
    #########################################
    dp.update(85, "Cleaning addons folder...")

    if os.path.exists(addons_path):
        for folder in os.listdir(addons_path):

            # Keep wizard only
            if folder == addon_id:
                continue

            # Remove ALL skins
            if folder.startswith("skin."):
                shutil.rmtree(os.path.join(addons_path, folder), ignore_errors=True)
                continue

            # Remove everything else
            shutil.rmtree(os.path.join(addons_path, folder), ignore_errors=True)


    #########################################
    # PHASE 4 – Remove skin settings inside addon_data
    #########################################
    addon_data = os.path.join(userdata, "addon_data")
    if os.path.exists(addon_data):
        for folder in os.listdir(addon_data):
            if folder.startswith("skin."):
                shutil.rmtree(os.path.join(addon_data, folder), ignore_errors=True)


    #########################################
    # DONE
    #########################################
    dp.update(100, "Reset complete!")
    dp.close()

    xbmcgui.Dialog().ok(addon_name, "Reset complete.\nKodi will now restart.")
    os._exit(0)
