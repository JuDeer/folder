######################
# main.py
######################
import sys, json, xbmcplugin, xbmcgui, xbmcaddon

from .utils import add_dir
from .parser import Parser
from addonvar import addon_icon, addon_fanart, local_string, buildfile

handle = int(sys.argv[1])

# -----------------------------
# ICON
# -----------------------------
addon       = xbmcaddon.Addon()
addon_path  = addon.getAddonInfo('path')
custom_icon = f"{addon_path}/resources/icon.png"
clean_icon  = f"{addon_path}/resources/clean.png"

# -----------------------------
# MAIN MENU
# -----------------------------
def main_menu():
    xbmcplugin.setPluginCategory(handle, 'Main Menu')

    add_dir(
        '[COLOR blue][B]Install Video[/B][/COLOR]',
        '',
        1,
        custom_icon,
        addon_fanart,
        'Install Video Add-ons',
        isFolder=True
    )

    add_dir(
        'Clean Junk',
        '',
        7,
        clean_icon,
        addon_fanart,
        'Clean cache, temp, and packages',
        isFolder=False
    )

    add_dir(
        '[COLOR red][B]Factory Reset[/B][/COLOR]',
        '',
        8,
        addon_icon,
        addon_fanart,
        'Factory Reset Kodi',
        isFolder=False
    )

    add_dir(
        'Settings',
        '',
        99,
        addon_icon,
        addon_fanart,
        'Wizard Settings',
        isFolder=False
    )


# -----------------------------
# BUILD MENU
# -----------------------------
def build_menu():
    xbmcplugin.setPluginCategory(handle, 'Kodi Builds')

    # Safety check: file must exist
    try:
        p = Parser(buildfile)
        build_json = p.get_list()
        builds = json.loads(build_json).get('builds', [])
    except Exception as e:
        xbmcgui.Dialog().ok("Build Error", f"Cannot load build list.\n{e}")
        return

    if not builds:
        xbmcgui.Dialog().ok("No Builds", "No builds found in the list.")
        return

    for build in builds:

        name        = build.get('name', 'Unknown Build')
        version     = build.get('version', '0')
        url         = build.get('url', '')
        icon        = build.get('icon', addon_icon)
        fanart      = build.get('fanart', addon_fanart)
        description = build.get('description', 'Kodi Build')

        add_dir(
            f"{name} • {version}",
            url,
            2,
            icon,
            fanart,
            description,
            name2=name,
            version=version,
            isFolder=False
        )
