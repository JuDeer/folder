######################
# addons_enable.py
######################
import glob, os, sqlite3, xbmc, xbmcaddon

from xml.dom.minidom import parse

from addonvar import addons_path, user_path

# --------------------------------------
# Detect Addons Database (Auto)
# --------------------------------------
def get_addons_db():
    """Find Addons database regardless of platform or version."""
    db_folder = os.path.join(user_path, "Database")

    if not os.path.exists(db_folder):
        return None

    # Look for AddonsXX.db
    for file in os.listdir(db_folder):
        if file.startswith("Addons") and file.endswith(".db"):
            return os.path.join(db_folder, file)

    return None

# --------------------------------------
# INSTALL DATE
# --------------------------------------
def get_install_date():
    """Returns a valid timestamp for database insert."""
    import time
    return int(time.time())

# --------------------------------------
# MAIN: Enable add-ons inside the build
# --------------------------------------
def enable_addons():
    """
    Enable all addons inside the extracted build.
    """

    addons_db = get_addons_db()

    if addons_db is None or not os.path.exists(addons_db):
        xbmc.log("[Wizard] Addons DB not found – skipping addon enable", xbmc.LOGINFO)
        return

    addon_xmls = sorted(glob.glob(os.path.join(addons_path, '*/addon.xml')))
    addon_ids = []

    # Extract addon IDs
    for xml_file in addon_xmls:
        try:
            root = parse(xml_file)
            tag = root.documentElement
            addon_ids.append(tag.getAttribute('id'))
        except:
            pass

    disabled = []

    # Determine which addons fail to load
    for addon_id in addon_ids:
        try:
            xbmcaddon.Addon(id=addon_id)
        except:
            disabled.append(addon_id)

    for addon_id in disabled:
        _enable_in_db(addon_id, addons_db)

    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')

# --------------------------------------
# Enable inside Addons DB
# --------------------------------------
def _enable_in_db(addon_id, addons_db):
    """Force-enable addon inside AddonsXX.db"""

    try:
        conn = sqlite3.connect(addons_db)
        c = conn.cursor()

        # Check existence
        c.execute("SELECT addonID FROM installed WHERE addonID = ?", (addon_id,))
        found = c.fetchone()

        if found is None:
            c.execute(
                "INSERT INTO installed (addonID, enabled, installDate) VALUES (?, ?, ?)",
                (addon_id, 1, get_install_date())
            )
        else:
            c.execute(
                "UPDATE installed SET enabled = 1 WHERE addonID = ?",
                (addon_id,)
            )

        conn.commit()
        conn.close()

    except Exception as e:
        xbmc.log(f"[Wizard] Failed enabling addon {addon_id}: {e}", xbmc.LOGINFO)
