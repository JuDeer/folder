######################
# parse.py
######################

import xml.etree.ElementTree as ET
import json
import xbmc
from .downloader import Downloader

class Parser:

    def __init__(self, url):
        self.url = url.strip()

    # ---------------------------------------------------------
    # GET BUILD LIST (XML or JSON)
    # ---------------------------------------------------------
    def get_list(self):

        if self.url.lower().endswith(".json"):
            page = self.get_page()
            return page if page else json.dumps({"builds": []})

        # Otherwise assume XML (default for all wizards)
        return self._parse_xml(self.get_page())

    # ---------------------------------------------------------
    # ALT XML PARSER (never used but kept for compatibility)
    # ---------------------------------------------------------
    def get_list2(self):
        return self._parse_xml(self.get_page())

    # ---------------------------------------------------------
    # SAFELY LOAD PAGE (remote or local)
    # ---------------------------------------------------------
    def get_page(self):

        # Remote URL
        if self.url.startswith("http"):
            d = Downloader(self.url)
            data = d.get_urllib()
            return data or ""     # Prevent None

        # Local file
        try:
            with open(self.url, "rb") as f:
                return f.read().decode("utf-8", errors="ignore")
        except Exception as e:
            xbmc.log(f"[Wizard] Parser file read error: {e}", xbmc.LOGINFO)
            return ""

    # ---------------------------------------------------------
    # INTERNAL XML PARSER
    # ---------------------------------------------------------
    def _parse_xml(self, text):

        if not text:
            return json.dumps({"builds": []})

        text = text.strip()

        try:
            root = ET.fromstring(text)
        except ET.ParseError:
            # Wrap in dummy root (required for Dropbox XML lists)
            try:
                root = ET.fromstring(f"<root>{text}</root>")
            except Exception as e:
                xbmc.log(f"[Wizard] XML parse failed: {e}", xbmc.LOGINFO)
                return json.dumps({"builds": []})

        item_list = []

        for item in root:
            entry = {}
            for child in item:
                entry[child.tag] = (child.text or "").strip()
            item_list.append(entry)

        return json.dumps({"builds": item_list})
