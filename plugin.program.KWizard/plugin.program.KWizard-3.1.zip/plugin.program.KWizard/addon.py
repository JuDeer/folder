######################
# addon.py
######################
import sys
from resources.lib.modules.plugin import router

if __name__ == '__main__':
    params = sys.argv[2] if len(sys.argv) > 2 else ""
    router(params[1:] if params.startswith("?") else params)
