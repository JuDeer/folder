######################
# params.py
######################
from urllib.parse import parse_qsl

class Params:
    def __init__(self, paramstring):
        self.params = dict(parse_qsl(paramstring or ""))

    def get_params(self):
        return self.params

    def _get(self, key, default=None):
        return self.params.get(key, default)

    def get_name(self):
        return self._get('name')

    def get_name2(self):
        return self._get('name2')

    def get_version(self):
        return self._get('version')

    def get_url(self):
        return self._get('url')

    def get_icon(self):
        return self._get('icon')

    def get_fanart(self):
        return self._get('fanart')

    def get_description(self):
        return self._get('description')

    def get_mode(self):
        val = self._get('mode')
        try:
            return int(val) if val is not None else None
        except:
            return None
