######################
# save_data.py
######################
import xbmc, xbmcvfs, os, shutil

from addonvar import addon_id, addon_path, user_path, packages

# ----------------------------------------------------------------------
# SAFE BACKUP HELPER
# ----------------------------------------------------------------------
def _ensure_packages_folder():
    """Make sure the backup folder exists."""
    if not os.path.exists(packages):
        try:
            os.makedirs(packages, exist_ok=True)
        except Exception as e:
            xbmc.log(f"[Wizard] Failed to create packages folder: {e}", xbmc.LOGERROR)


def backup(path, file):
    """
    Backup a single file/folder into the packages folder.
    Safer version (won't overwrite other data).
    """
    _ensure_packages_folder()

    source = os.path.join(path, file)
    destination = os.path.join(packages, file)

    if os.path.exists(source):
        try:
            # Remove existing backup first
            if os.path.exists(destination):
                if os.path.isfile(destination) or os.path.islink(destination):
                    os.unlink(destination)
                else:
                    shutil.rmtree(destination, ignore_errors=True)
        except:
            pass

        try:
            shutil.move(source, destination)
        except Exception as e:
            xbmc.log(f"[Wizard] Failed backup {file}: {e}", xbmc.LOGINFO)


def restore(path, file):
    """
    Restore a single file/folder from the packages folder safely.
    """
    source = os.path.join(packages, file)
    destination = os.path.join(path, file)

    if os.path.exists(source):

        # Remove destination first
        if os.path.exists(destination):
            try:
                if os.path.isfile(destination) or os.path.islink(destination):
                    os.unlink(destination)
                else:
                    shutil.rmtree(destination, ignore_errors=True)
            except Exception as e:
                xbmc.log(
                    f"[Wizard] Failed deleting existing {destination}: {e}",
                    xbmc.LOGINFO
                )

        try:
            shutil.move(source, destination)
        except Exception as e:
            xbmc.log(f"[Wizard] Restore failed for {file}: {e}", xbmc.LOGINFO)


# ----------------------------------------------------------------------
# SAVE SETTINGS (Minimal Wizard → Only backup wizard addon)
# ----------------------------------------------------------------------
def save_check(EXCLUDES):
    """
    Your minimal Wizard does not support saving user settings.
    Simply return exclusions unchanged.
    """
    return EXCLUDES


def save_backup():
    """
    Backup ONLY the wizard addon folder:
    special://home/addons/plugin.program.KWizard/
    """
    _ensure_packages_folder()

    # Backup from addons folder, not userdata
    backup(os.path.dirname(addon_path), addon_id)


def save_restore():
    """
    Restore the wizard addon folder and clean up backup folder.
    """
    restore(os.path.dirname(addon_path), addon_id)

    # Cleanup - remove packages folder safely
    try:
        shutil.rmtree(packages)
    except:
        pass
