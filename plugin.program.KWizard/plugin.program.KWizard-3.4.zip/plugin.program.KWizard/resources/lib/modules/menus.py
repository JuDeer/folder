######################
# main.py
######################
import sys, json, xbmcplugin, xbmcgui, xbmcaddon

from .utils import add_dir
from .parser import Parser
from addonvar import addon_icon, addon_fanart, local_string, buildfile

handle = int(sys.argv[1])

# -----------------------------
# ICON
# -----------------------------
addon       = xbmcaddon.Addon()
addon_path  = addon.getAddonInfo('path')
custom_icon = f"{addon_path}/resources/icon.png"
clean_icon  = f"{addon_path}/resources/clean.png"
reset_icon  = f"{addon_path}/resources/reset.png"

# -----------------------------
# MAIN MENU
# -----------------------------
def main_menu():
    xbmcplugin.setPluginCategory(handle, 'Main Menu')

    add_dir(
        '[COLOR blue]ដំឡើងវីដេអូ[/COLOR] Install Video',
        '',
        1,
        custom_icon,
        addon_fanart,
        'ចុចលើ Install Video ហើយបន្ទាប់មកជ្រើសវីដេអូរបស់អ្នក',
        isFolder=True
    )

    add_dir(
        'សម្អាតសំរាម Clean Junk',
        '',
        7,
        clean_icon,
        addon_fanart,
        'វានឹងសម្អាតសារធាតុឥតប្រយោជន៍ ដើម្បីឱ្យ Kodi របស់អ្នកដំណើរការលឿន និងមានស្ថេរភាពជាងមុន',
        isFolder=False
    )

    add_dir(
        '[COLOR red]ត្រឡប់ទៅដើមវិញ[/COLOR] Factory Reset',
        '',
        8,
        reset_icon,
        addon_fanart,
        '[COLOR red]ព្រមាន៖[/COLOR] ការធ្វើ factory reset នឹងលុបទិន្នន័យ ការកំណត់ និងកម្មវិធីទាំងអស់ ហើយនឹងធ្វើឱ្យឧបករណ៍ត្រឡប់ទៅស្ថានភាពដើម',
        isFolder=False
    )

    #add_dir(
    #    'Settings',
    #    '',
    #    99,
    #    addon_icon,
    #    addon_fanart,
    #    'Wizard Settings',
    #    isFolder=False
    #)


# -----------------------------
# BUILD MENU
# -----------------------------
def build_menu():
    xbmcplugin.setPluginCategory(handle, 'Kodi Builds')

    # Safety check: file must exist
    try:
        p = Parser(buildfile)
        build_json = p.get_list()
        builds = json.loads(build_json).get('builds', [])
    except Exception as e:
        xbmcgui.Dialog().ok("Build Error", f"Cannot load build list.\n{e}")
        return

    if not builds:
        xbmcgui.Dialog().ok("No Builds", "No builds found in the list.")
        return

    for build in builds:

        name        = build.get('name', 'Unknown Build')
        version     = build.get('version', '0')
        url         = build.get('url', '')
        icon        = build.get('icon', addon_icon)
        fanart      = build.get('fanart', addon_fanart)
        description = build.get('description', 'Kodi Build')

        add_dir(
            f"{name} • {version}",
            url,
            2,
            icon,
            fanart,
            description,
            name2=name,
            version=version,
            isFolder=False
        )
