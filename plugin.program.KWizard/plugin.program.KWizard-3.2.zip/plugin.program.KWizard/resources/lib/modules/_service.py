######################
# _service.py
######################
import xbmc, xbmcgui, xbmcvfs, os, shutil

from addonvar import setting, setting_set, addon_name
from .maintenance import clear_packages, clear_cache, clear_temp

class Startup:

    def run_startup(self):

        # ============================================================
        # tvOS PROTECTION — Skip all startup cleaning
        # ============================================================
        if xbmc.getCondVisibility("System.Platform.tvOS"):
            xbmc.log("[Wizard] Startup cleaning skipped on tvOS — protecting system add-ons.", xbmc.LOGINFO)
            return

        # ============================================================
        # 1) PROCESS DELETE QUEUE (used when Fresh Start can't delete)
        # ============================================================
        delete_queue = xbmcvfs.translatePath("special://userdata/delete_queue.txt")

        if xbmcvfs.exists(delete_queue):
            try:
                with open(delete_queue, "r") as f:
                    paths = f.read().splitlines()

                for p in paths:
                    if os.path.exists(p):
                        xbmc.log(f"[Wizard] Removing leftover on reboot: {p}", xbmc.LOGINFO)
                        shutil.rmtree(p, ignore_errors=True)

                os.unlink(delete_queue)

            except Exception as e:
                xbmc.log(f"[Wizard] Delete queue error: {e}", xbmc.LOGERROR)

        # ============================================================
        # 2) AUTO CLEAN ON STARTUP (non-tvOS only)
        # ============================================================
        if setting('autoclean_onstartup') == 'true':
            xbmc.sleep(1200)

            try: clear_cache()
            except: pass

            try: clear_temp()
            except: pass

            try: clear_packages()
            except: pass

        # ============================================================
        # 3) FIRST RUN ACTIONS (safe on all platforms)
        # ============================================================
        if setting('firstrun') == 'true':

            xbmc.executeJSONRPC(
                '{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
                '"params":{"setting":"addons.unknownsources","value":true},"id":1}'
            )

            xbmc.executeJSONRPC(
                '{"jsonrpc":"2.0","method":"Settings.SetSettingValue",'
                '"params":{"setting":"addons.allowaddonrepos","value":true},"id":1}'
            )

            xbmc.log("[Wizard] Enabled Unknown Sources + Any Repository", xbmc.LOGINFO)

            setting_set('firstrun', 'false')
            xbmc.sleep(500)

