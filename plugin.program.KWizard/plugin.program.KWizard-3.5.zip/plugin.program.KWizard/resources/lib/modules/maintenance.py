######################
# maintenance.py
######################
import os, shutil, xbmc, xbmcgui, xbmcvfs

from addonvar import addon_name, addon_id, userdata, addons_path, packages, local_string

############################################
# CLEAR CACHE
############################################
def clear_cache():
    cache_dirs = [
        os.path.join(userdata, 'cache'),
        os.path.join(userdata, 'temp'),
        os.path.join(userdata, 'addon_data', 'temp'),
    ]

    for cdir in cache_dirs:
        if os.path.exists(cdir):
            shutil.rmtree(cdir, ignore_errors=True)

    xbmc.log("[Wizard] Cache cleared.", xbmc.LOGINFO)

############################################
# CLEAR TEMP FILES
############################################
def clear_temp():
    temp_dirs = [
        os.path.join(userdata, "temp"),
        os.path.join(userdata, "cache"),
    ]

    for tdir in temp_dirs:
        if os.path.exists(tdir):
            shutil.rmtree(tdir, ignore_errors=True)

    xbmc.log("[Wizard] Temp files cleared.", xbmc.LOGINFO)

############################################
# CLEAR PACKAGES
############################################
def clear_packages():
    if not os.path.exists(packages):
        return

    for filename in os.listdir(packages):
        file_path = os.path.join(packages, filename)
        if os.path.isfile(file_path) or os.path.islink(file_path):
            os.unlink(file_path)
        else:
            shutil.rmtree(file_path, ignore_errors=True)

    xbmc.log("[Wizard] Packages cleared.", xbmc.LOGINFO)

############################################
# CLEAR LOGS (kodi.log + kodi.old.log)
############################################
def clear_logs():
    log_path = xbmcvfs.translatePath("special://logpath")
    log_file = os.path.join(log_path, "kodi.log")
    old_log  = os.path.join(log_path, "kodi.old.log")

    for f in [log_file, old_log]:
        if os.path.exists(f):
            try:
                os.remove(f)
            except:
                pass

    xbmc.log("[Wizard] Logs cleaned.", xbmc.LOGINFO)

############################################
# CLEAR special://temp
############################################
def clear_special_temp():
    temp_path = xbmcvfs.translatePath("special://temp")
    if os.path.exists(temp_path):
        shutil.rmtree(temp_path, ignore_errors=True)
    xbmc.log("[Wizard] special://temp cleaned.", xbmc.LOGINFO)

############################################
# CLEAR THUMBNAILS 
############################################
def clear_thumbnails():
    thumbs = xbmcvfs.translatePath("special://thumbnails")
    if os.path.exists(thumbs):
        shutil.rmtree(thumbs, ignore_errors=True)

    xbmc.log("[Wizard] Thumbnails cleared", xbmc.LOGINFO)

############################################
# FULL CLEAN 
############################################
def full_clean():
    dp = xbmcgui.DialogProgress()
    dp.create(addon_name, "ចាប់ផ្តើមសម្អាត\n Start Cleaning")

    dp.update(5, "Clearing logs...")
    clear_logs()

    dp.update(20, "Clearing cache...")
    clear_cache()

    dp.update(40, "Clearing temp...")
    clear_temp()

    dp.update(60, "Cleaning Kodi temp directory...")
    clear_special_temp()

    dp.update(80, "Removing packages...")
    clear_packages()

    dp.update(95, "Cleaning thumbnails...")
    clear_thumbnails()

    dp.update(100, "Full Clean complete!")
    dp.close()

    xbmcgui.Dialog().ok(addon_name, "សម្អាតរួចរាល់\nClean successfully")

############################################
# FRESH START (COMPLETE WIPE)
############################################
def fresh_start():
    yes = xbmcgui.Dialog().yesno(
        "ត្រឡប់ទៅដើមវិញ Factory Reset",
        "[COLOR red][B]ព្រមាន៖[/B][/COLOR] វានឹងលុប Kodi ទៅការកំណត់ដើម។\n"
        "[COLOR red][B]WARNING:[/B][/COLOR] This will reset Kodi to factory defaults.\n\n"
        "សូមបន្ត / Continue?",
        yeslabel="យល់ព្រម / Yes",
        nolabel="មិនព្រម / No"
    )

    if not yes:
        return

    dp = xbmcgui.DialogProgress()
    dp.create(addon_name, "Performing Fresh Start...")

    KEEP_ADDONS = [addon_id]   # Keep wizard ONLY
    KEEP_FOLDERS = ["addon_data"]

    #########################################
    # PHASE 1 – Delete all files in userdata
    #########################################
    dp.update(25, "Removing userdata files...")
    for root, dirs, files in os.walk(userdata):
        for f in files:
            try:
                os.remove(os.path.join(root, f))
            except:
                pass

    #########################################
    # PHASE 2 – Remove userdata folders except addon_data
    #########################################
    dp.update(55, "Cleaning userdata folders...")
    for item in os.listdir(userdata):
        if item not in KEEP_FOLDERS:
            shutil.rmtree(os.path.join(userdata, item), ignore_errors=True)

    #########################################
    # PHASE 3 – Clean addons folder (TVOS SAFE)
    #########################################
    dp.update(85, "Cleaning addons folder...")

    if xbmc.getCondVisibility("system.platform.tvos"):
        xbmc.log("[Wizard] TVOS detected - skipping full addons wipe.", xbmc.LOGINFO)

        if os.path.exists(addons_path):
            for folder in os.listdir(addons_path):
                if folder.startswith("skin.") and folder != "skin.estuary":
                    shutil.rmtree(os.path.join(addons_path, folder), ignore_errors=True)
    else:
        if os.path.exists(addons_path):
            for folder in os.listdir(addons_path):

                if folder == addon_id:
                    continue

                if folder.startswith("skin."):
                    shutil.rmtree(os.path.join(addons_path, folder), ignore_errors=True)
                    continue

                shutil.rmtree(os.path.join(addons_path, folder), ignore_errors=True)

    #########################################
    # PHASE 4 – Remove skin settings inside addon_data
    #########################################
    addon_data_dir = os.path.join(userdata, "addon_data")
    if os.path.exists(addon_data_dir):
        for folder in os.listdir(addon_data_dir):
            if folder.startswith("skin."):
                shutil.rmtree(os.path.join(addon_data_dir, folder), ignore_errors=True)

    #########################################
    # DONE
    #########################################
    dp.update(100, "Reset complete!")
    dp.close()

    xbmcgui.Dialog().ok(addon_name, "Reset complete.\nKodi will now restart.")
    os._exit(0)
