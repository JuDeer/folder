######################
# utils.py
######################
import xbmc, xbmcgui, xbmcplugin, sys

from urllib.parse import quote_plus
from addonvar import addon_name, addon_version


# ------------------------------------------------
# ADD MENU ITEM (supports CENTER, \n, full formatting)
# ------------------------------------------------
def add_dir(
        name,
        url,
        mode,
        icon,
        fanart,
        description,
        name2='',
        version='',
        isFolder=True
    ):

    # Build plugin URL
    u = (
        sys.argv[0]
        + "?url=" + quote_plus(url)
        + "&mode=" + str(mode)
        + "&name=" + quote_plus(name)
        + "&icon=" + quote_plus(icon)
        + "&fanart=" + quote_plus(fanart)
        + "&description=" + quote_plus(description)
        + "&name2=" + quote_plus(name2)
        + "&version=" + quote_plus(version)
    )

    # ---------------------------------------------
    # IMPORTANT: Create ListItem WITHOUT label
    # Then set label manually so Kodi parses tags.
    # ---------------------------------------------
    liz = xbmcgui.ListItem(label="")  
    liz.setLabel(name)     # Enable formatting: COLOR, CENTER, \n, B, I

    # Artwork
    liz.setArt({
        "icon": icon,
        "thumb": icon,
        "fanart": fanart
    })

    # Info (needed for some skins)
    liz.setInfo("video", {
        "title": name,
        "plot": description
    })

    # Allow formatting + non-playable entries
    liz.setProperty("IsPlayable", "false")

    # Final add to UI
    xbmcplugin.addDirectoryItem(
        handle=int(sys.argv[1]),
        url=u,
        listitem=liz,
        isFolder=isFolder
    )


# ------------------------------------------------
# LOGGER HELPERS
# ------------------------------------------------
def Log(msg: str):
    """Primary logging function with addon prefix."""
    xbmc.log(f"[{addon_name} v{addon_version}] {msg}", xbmc.LOGINFO)


def log(label, value):
    """Debug helper for printing variable values."""
    xbmc.log(f"{label}: {value}", xbmc.LOGINFO)
