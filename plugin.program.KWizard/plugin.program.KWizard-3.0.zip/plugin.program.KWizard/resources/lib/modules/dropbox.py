######################
# dropbox.py
######################
import xbmc, xbmcgui, os

from urllib.request import Request, urlopen
from resources.lib.modules.utils import Log

def DownloadFile(url, dst):
    """
    Lightweight safe downloader for XML/JSON build list files.
    Pure urllib (Apple TV safe).
    """

    try:
        req = Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (KodiWizard/1.0)",
                "Accept": "*/*",
                "Connection": "keep-alive"
            }
        )

        # 10 second timeout (important!)
        response = urlopen(req, timeout=10)

        # Download in chunks (prevents partial corrupt files)
        with open(dst, "wb") as f:
            while True:
                chunk = response.read(1024 * 64)  # 64KB
                if not chunk:
                    break
                f.write(chunk)

        # Confirm file exists + is not zero bytes
        if os.path.exists(dst) and os.path.getsize(dst) > 0:
            Log(f"Download OK: {dst}")
            return True
        else:
            raise Exception("Downloaded file is empty or missing.")

    except Exception as e:
        xbmc.log(f"[Wizard] DownloadFile error: {e}", xbmc.LOGINFO)

        # Remove partially downloaded file
        try:
            if os.path.exists(dst):
                os.unlink(dst)
        except:
            pass

        xbmcgui.Dialog().ok("Error", f"Failed to download:\n{url}")
        return False

    return False
