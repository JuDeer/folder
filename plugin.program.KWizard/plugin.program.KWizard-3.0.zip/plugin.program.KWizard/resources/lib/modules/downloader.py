######################
# downloader.py
######################
import os, xbmc, xbmcgui

from urllib.request import Request, urlopen

class Downloader:
    def __init__(self, url):
        self.url = url
        self.headers = {
            "User-Agent": (
                "Mozilla/5.0 (KodiBuildInstaller; "
                "AppleTV/Android/FireOS/Windows)"
            ),
            "Connection": "keep-alive",
            "Accept": "*/*",
        }

    # --------------------------------------------------------------------
    # TRY REQUESTS FIRST (BEST FOR DROPBOX LINKS)
    # --------------------------------------------------------------------
    def _try_requests(self):
        try:
            import requests
            r = requests.get(self.url, headers=self.headers, stream=True, timeout=10)
            if r.status_code == 200:
                return r
            return None
        except:
            return None

    # --------------------------------------------------------------------
    # FALLBACK URLLIB (ALWAYS AVAILABLE)
    # --------------------------------------------------------------------
    def _urllib_response(self):
        req = Request(self.url, headers=self.headers)
        return urlopen(req)

    # --------------------------------------------------------------------
    # SIMPLE URL FETCH FOR XML/JSON
    # --------------------------------------------------------------------
    def get_urllib(self):
        try:
            req = Request(self.url, headers=self.headers)
            response = urlopen(req, timeout=10)
            data = response.read()
            return data.decode("utf-8", errors="ignore")
        except Exception as e:
            xbmc.log(f"[Wizard] get_urllib error: {e}", xbmc.LOGINFO)
            return ""

    # --------------------------------------------------------------------
    # GET CONTENT LENGTH (FOR PROGRESS)
    # --------------------------------------------------------------------
    def _content_length(self, response, using_requests):
        try:
            if using_requests:
                return response.headers.get("content-length")
            else:
                return response.getheader("content-length")
        except:
            return None

    # --------------------------------------------------------------------
    # DOWNLOAD BUILD ZIP WITH PROGRESS BAR
    # --------------------------------------------------------------------
    def download_build(self, name, zippath, meth="urllib"):

        response = None
        using_requests = False

        # Use "requests" first if caller requests it
        if meth == "requests":
            response = self._try_requests()
            if response:
                using_requests = True

        # If requests not available → use urllib
        if response is None:
            try:
                response = self._urllib_response()
                using_requests = False
            except Exception as e:
                xbmcgui.Dialog().ok("Download Error", f"Unable to open URL.\n{e}")
                return False

        # Get size safely
        length = self._content_length(response, using_requests)
        total_size = int(length) if length else None
        total_mb = total_size // 1000000 if total_size else "?"

        dp = xbmcgui.DialogProgress()
        dp.create(f"{name} - Download", "Downloading build…")

        size = 0
        cancelled = False

        blocksize = 1024 * 1024  # 1MB

        try:
            with open(zippath, "wb") as f:

                if using_requests:
                    # STREAM USING REQUESTS
                    for chunk in response.iter_content(chunk_size=blocksize):
                        if not chunk:
                            break

                        f.write(chunk)
                        size += len(chunk)

                        percent = int(size / total_size * 100) if total_size else 50
                        dp.update(percent, f"{size//1000000}/{total_mb} MB downloaded")

                        if dp.iscanceled():
                            cancelled = True
                            break

                else:
                    # STREAM USING URLLIB
                    while True:
                        chunk = response.read(blocksize)
                        if not chunk:
                            break

                        f.write(chunk)
                        size += len(chunk)

                        percent = int(size / total_size * 100) if total_size else 50
                        dp.update(percent, f"{size//1000000}/{total_mb} MB downloaded")

                        if dp.iscanceled():
                            cancelled = True
                            break

        finally:
            try:
                if using_requests:
                    response.close()
            except:
                pass

        # If cancelled → delete the partial file
        if cancelled:
            try:
                os.unlink(zippath)
            except:
                pass

            dp.close()
            xbmcgui.Dialog().ok("Cancelled", "Download cancelled by user.")
            return False

        dp.update(100, "Download complete")
        dp.close()
        return True
