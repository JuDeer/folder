######################
# build_install.py
######################
import os, xbmc

from zipfile import ZipFile, BadZipFile

from .downloader import Downloader
from .maintenance import fresh_start, clear_packages

from addonvar import (
    dp, dialog, zippath, addon_name, home,
    setting_set, local_string
)

def main(name, name2, version, url):

    # Only confirm install
    yesInstall = dialog.yesno(
        name,
        local_string(30028),
        nolabel=local_string(30029),
        yeslabel=local_string(30030)
    )

    if not yesInstall:
        return

    # Direct install – NO fresh start
    build_install(name, name2, version, url)

def build_install(name, name2, version, url):

    # Remove previous temp zip
    if os.path.exists(zippath):
        try:
            os.unlink(zippath)
        except:
            pass

    # Download build ZIP
    d = Downloader(url)

    if "dropbox" in url.lower():
        d.download_build(name, zippath, meth="requests")
    else:
        d.download_build(name, zippath, meth="urllib")

    # Validate ZIP
    if not os.path.exists(zippath):
        dialog.ok(addon_name, "Download failed.")
        return

    # Extract ZIP
    dp.create(addon_name, local_string(30034)) 
    dp.update(25)

    try:
        with ZipFile(zippath, 'r') as zf:
            zf.extractall(path=home)
    except BadZipFile:
        dp.close()
        dialog.ok(addon_name, "Build file is corrupted or incomplete.")
        return

    dp.update(100, local_string(30035))
    dp.close()

    # Remove temp ZIP
    try:
        os.unlink(zippath)
    except:
        pass

    # Cleanup packages
    try:
        clear_packages()
    except:
        pass

    # Save build info
    setting_set('buildname', name2)
    setting_set('buildversion', version)

    # Tell service to enable addons + switch skin
    setting_set('firstrun', "true")

    dialog.ok(addon_name, local_string(30036))   # Install Complete

    # Restart Kodi
    os._exit(1)
