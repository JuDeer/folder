######################
# skinSwitch.py
######################
import xbmc, xbmcvfs, os

from addonvar import addons_path, setting, setting_set

def detect_skin_from_build():
    """
    Automatically detects any installed skin inside the build.
    Excludes Estuary unless no other skins exist.
    Uses xbmcvfs to stay compatible with Apple TV / Android.
    """

    build_skins = []

    try:
        dirs = xbmcvfs.listdir(addons_path)[0]  # ensure platform-safe listing

        for folder in dirs:
            if folder.startswith("skin."):
                # Ignore Estuary unless it's the ONLY skin
                if folder != "skin.estuary":
                    build_skins.append(folder)

        # If custom skin found, return first
        if build_skins:
            return build_skins[0]

        # Otherwise fallback to Estuary
        return "skin.estuary"

    except Exception as e:
        xbmc.log(f"[Wizard] Skin detection error: {e}", xbmc.LOGINFO)
        return "skin.estuary"


def switch_to_build_skin():
    """
    Switches Kodi to the correct skin after installing a build.
    Fully portable-mode compatible.
    Fully Apple TV / Android 14 / Windows compatible.
    """

    # Load saved skin
    TARGET_SKIN = setting("build_skin")

    # Auto detect skin if not set
    if not TARGET_SKIN:
        TARGET_SKIN = detect_skin_from_build()
        setting_set("build_skin", TARGET_SKIN)

    FALLBACK_SKIN = "skin.estuary"

    xbmc.log(f"[Wizard] Switching to skin: {TARGET_SKIN}", xbmc.LOGINFO)

    # Wait for addon to be recognized by Kodi
    tries = 0
    max_tries = 30

    while tries < max_tries:
        if xbmc.getCondVisibility(f"System.HasAddon({TARGET_SKIN})"):
            break
        xbmc.sleep(1000)
        tries += 1

    if tries >= max_tries:
        xbmc.log(
            f"[Wizard] Skin {TARGET_SKIN} not detected. Using fallback.",
            xbmc.LOGINFO
        )
        TARGET_SKIN = FALLBACK_SKIN

    # JSON-RPC format must be exact or skin switching fails
    json_query = {
        "jsonrpc": "2.0",
        "method": "Settings.SetSettingValue",
        "params": {
            "setting": "lookandfeel.skin",
            "value": TARGET_SKIN
        },
        "id": 1
    }

    import json
    xbmc.executeJSONRPC(json.dumps(json_query))

    xbmc.sleep(1000)
    xbmc.executebuiltin("ReloadSkin()")

    xbmc.log(f"[Wizard] Skin successfully switched to {TARGET_SKIN}", xbmc.LOGINFO)
