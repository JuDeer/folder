######################
# plugin.py
######################
import xbmc, xbmcplugin, sys

from .params import Params

# MENUS
from .menus import main_menu, build_menu

# BUILD INSTALLER
from .build_install import main as install_build

# MAINTENANCE (FULL CLEAN + FRESH START ONLY)
from .maintenance import full_clean, fresh_start

# SETTINGS
from addonvar import addon

handle = int(sys.argv[1])

def router(paramstring):
    p = Params(paramstring)

    mode    = p.get_mode()
    name    = p.get_name()
    name2   = p.get_name2()
    version = p.get_version()
    url     = p.get_url()

    xbmcplugin.setContent(handle, 'files')

    # -----------------------------------
    # MAIN MENU
    # -----------------------------------
    if mode is None:
        main_menu()

    # -----------------------------------
    # BUILD MENU
    # -----------------------------------
    elif mode == 1:
        build_menu()

    # -----------------------------------
    # INSTALL BUILD
    # -----------------------------------
    elif mode == 2:
        install_build(name, name2, version, url)
        return

    # -----------------------------------
    # FULL CLEAN (cache/temp/packages)
    # -----------------------------------
    elif mode == 7:
        full_clean()
        return

    # -----------------------------------
    # FRESH START (wipe userdata)
    # -----------------------------------
    elif mode == 8:
        fresh_start()
        return

    # -----------------------------------
    # SETTINGS
    # -----------------------------------
    elif mode == 99:
        addon.openSettings()
        return

    xbmcplugin.endOfDirectory(handle)
