import json
import base64
import xbmc
import xbmcgui
import xml.etree.ElementTree as ET
from .maintenance import clear_packages
from addonvar import setting, setting_set, buildfile, addon_name, isBase64, headers, dialog, local_string

current_build = setting('buildname')
try:
	current_version = float(setting('buildversion')) 
except:
	current_version = 0.0

class Startup:
	
	def check_updates(self):
	   	if current_build == 'No Build Installed':
	   		return
	   	response = self.get_page(buildfile)
	   	version = 0.0
	   	try:
	   		builds = json.loads(response)['builds']
	   		for build in builds:
	   				if build.get('name') == current_build:
	   					version = float(build.get('version'))
	   					break
	   	except:
	   		builds = ET.fromstring(response)
	   		for tag in builds.findall('build'):
	   				if tag.find('name').text == current_build:
	   					version = float(tag.find('version').text)
	   					break
	   	if version > current_version:
	   		xbmcgui.Dialog().ok(addon_name, local_string(30047) + ' ' + current_build +' ' + local_string(30048) + '\n' + local_string(30049) + ' ' + str(current_version) + '\n' + local_string(30050) + ' ' + str(version) + '\n' + local_string(30051) + ' ' + addon_name + '.')  # New Version Available
	   	else:
	   		return

	def file_check(self, bfile):
		if isBase64(bfile):
			return base64.b64decode(bfile).decode('utf8')
		else:
			return bfile
			
	def get_page(self, url):
	   	from urllib.request import Request,urlopen
	   	req = Request(self.file_check(url), headers = headers)
	   	return urlopen(req).read()
    	
	def save_menu(self):
		save_items = []
		choices = ["Favourites", "Sources", "Debrid - Resolve URL", "Advanced Settings"]
		save_select = dialog.multiselect(addon_name + ' - ' + local_string(30052),choices, preselect=[])  # Select Save Items
		if save_select == None:
			return
		else:
			for index in save_select:
				save_items.append(choices[index])
		if 'Favourites' in save_items:
			setting_set('savefavs','true')
		else:
			setting_set('savefavs','false')
		if 'Sources' in save_items:
			setting_set('savesources', 'true')
		else:
			setting_set('savesources', 'false')
		if 'Debrid - Resolve URL' in save_items:
			setting_set('savedebrid','true')
		else:
			setting_set('savedebrid','false')
		if 'Advanced Settings' in save_items:
			setting_set('saveadvanced','true')
		else:
			setting_set('saveadvanced','false')
	
		setting_set('firstrunSave', 'true')
	

	def run_startup(self):
		if setting('autoclearpackages')=='true':
			xbmc.sleep(2000)
			clear_packages()
		#if not setting('firstrunSave')=='true':
			#xbmc.sleep(2000)
			#self.save_menu()
		#self.check_updates()
		#self.notify_check()
		if setting('firstrun') == 'true':
			from resources.lib.modules import addons_enable
			addons_enable.enable_addons()
		setting_set('firstrun', 'false')