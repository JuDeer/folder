# ── Compatibility & Imports ─────────────────────────────────────
import os, sys, re, ast, json, gzip, time, random, base64, string, requests, urllib.parse
import xml.dom.minidom, xml.etree.ElementTree as ET

# ── Kodi Modules ────────────────────────────────────────────────
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs

# ── External Libraries ──────────────────────────────────────────
import resolveurl
from bs4 import BeautifulSoup
from urllib.parse import urlparse, quote_plus, unquote_plus, urljoin
from html import unescape as html_unescape
from resources.lib.handlers_common import USER_AGENT
from resources.lib.constants import khmertv

from resources.lib import (
    video4khmer,
    idrama,
    vip,
    ckch7,
    phumikhmer,
    khmerav,
    sunday,
    flixhq,
    lookmovie,
)

from resources.lib.handlers_blogid import (
    extract_all_blogger_json_urls_from_page,
    extract_vip_blogger_json_urls_from_page,
    parse_blogger_video_links,
    parse_blogger_video_links_script,
    is_vip_url,
    is_idrama_url,
)

from resources.lib.handlers_playback import (
    EPISODE_PLAYERS,
    resolve_redirect,
    VIDEOLINKS,
    enable_inputstream_adaptive,
    Playloop,
    VIDEO_HOSTING,
    Play_VIDEO,
)

# ── Imports ────────────────────────────────────────────────
from resources.lib.handlers_flixhq import OpenURL as OpenURL_SG, OpenSoup as OpenSoup_SG, URL
from resources.lib.handlers_khmer import OpenURL as OpenURL_KH, OpenSoup as OpenSoup_KH

# ── SerialGo specific aliases (defined first) ──────────────
OpenURL = OpenURL_SG
OpenSoup = OpenSoup_SG

# ── Global fallback (legacy Khmer default) ─────────────────
OpenURL = OpenURL_KH
OpenSoup = OpenSoup_KH

# USER_AGENT = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"

# --- HTTP session & tiny negative cache ---
_SESSION = requests.Session()

# ── Logging Helper ──────────────────────────────────────────────
def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)
    
# ── Add-on Constants ────────────────────────────────────────────
ADDON_ID      = 'plugin.video.KDubbed'
ADDON         = xbmcaddon.Addon(id=ADDON_ID)
ADDON_PATH    = ADDON.getAddonInfo('path')
DATA_PATH     = xbmcvfs.translatePath(f'special://profile/addon_data/{ADDON_ID}')
PLUGIN_HANDLE = int(sys.argv[1])


# ── Base URLs ───────────────────────────────────────────────────
VIDEO4KHMER  = 'https://www.video4khmer36.com/'
PHUMIK       = 'https://www.phumikhmer1.club/'
KHMERAVENUE  = 'https://www.khmeravenue.com/'
MERLKON      = 'https://www.khmerdrama.com/'
CKCH7        = 'http://www.ckh7.com/'
SUNDAY       = 'https://www.sundaydrama.com/'
VIP          = 'https://phumikhmer.vip/'
IDRAMA       = 'https://www.idramahd.com/'
BASE_URL     = 'https://flixhq.to/'

# ── Icons and Fanart ────────────────────────────────────────────
IMAGE_PATH     = os.path.join(ADDON_PATH, 'resources', 'images')
ICON_JOLCHET   = os.path.join(IMAGE_PATH, 'icon.png')
ICON_SEARCH    = os.path.join(IMAGE_PATH, 'search1.png')
ICON_KHMERTV   = os.path.join(IMAGE_PATH, 'khmertv.png')
ICON_LOOKM     = os.path.join(IMAGE_PATH, 'lookm.png')
FANART         = os.path.join(IMAGE_PATH, 'fanart.jpg')
ICON_KHMERAVE  = "https://www.khmeravenue.com/wp-content/themes/avenue/img/logo.png"
ICON_MERLKON   = "https://www.khmerdrama.com/wp-content/themes/avenue/img/logo.png"
ICON_VIP       = "https://raw.githubusercontent.com/goupon/file/master/logo/vip.jpg"
ICON_SUNDAY    = "https://raw.githubusercontent.com/goupon/file/master/logo/SD.jpg"
ICON_IDRAMA    = "https://www.idramahd.com/wp-content/uploads/2024/12/idramahd-Black.png"


# ── Virtual Keyboard Input ──────────────────────────────────────
def GetInput(message, heading, is_hidden=False):
    keyboard = xbmc.Keyboard('', message, is_hidden)
    keyboard.setHeading(heading)
    keyboard.doModal()
    return keyboard.getText() if keyboard.isConfirmed() else ""

# Main Menu
def HOME():
    addDir("[COLOR yellow][B][I]SEARCH[/I][/B][/COLOR]", MERLKON, "search", ICON_SEARCH)
    addDir("Khmer Live TV", khmertv, "khmer_livetv", ICON_KHMERTV) 

    # ── Structured site definitions ─────────────────────────────
    sites = [
        {
            "title": "Vip • Sunday • iDrama • KhmerAve • Merlkon",
            "categories": [
                ("VIP", f"{VIP}", ICON_VIP, "index_vip"),            
                ("Sunday", f"{SUNDAY}", ICON_SUNDAY, "index_sunday"),
                ("iDrama", f"{IDRAMA}", ICON_IDRAMA, "index_idrama"),                
                ("KhmerAve", f"{KHMERAVENUE}album/", ICON_KHMERAVE, "index_khmeravenue"),
                ("Merlkon", f"{MERLKON}album/", ICON_MERLKON, "index_merlkon")
            ]
        },       
        {
            "title": "Video4Khmer",
            "logo": "https://www.video4khmer36.com/templates/pkakrovan/images/all/logo.png",
            "action": "index_video4u",
            "categories": [
                ("Cambodia", f"{MERLKON}country/cambodia/", "index_merlkon")
                #("Chinese Aired", f"{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-to-be-continued-catalogue-2673-page-1.html"),
                #("Chinese Completed", f"{VIDEO4KHMER}khmer-movie-category/chinese-series-drama-watch-online-free-catalogue-506-page-1.html"),
                #("Thai Aired", f"{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-to-be-continued-catalogue-2674-page-1.html"),
                #("Thai Completed", f"{VIDEO4KHMER}khmer-movie-category/thai-lakorn-drama-watch-online-free-catalogue-537-page-1.html"),
                #("Korean Aired", f"{VIDEO4KHMER}khmer-movie-category/korean-drama-to-be-continued-catalogue-508-page-1.html"),
                #("Korean Completed", f"{VIDEO4KHMER}khmer-movie-category/korean-drama-watch-online-free-catalogue-507-page-1.html")
            ]
        },
        {
            "title": "PhumiKhmer",
            "logo": "https://phumikhmer2.com/home/img/logo.png",
            "action": "index_phumik",
            "categories": [
                ("Thai", f"{PHUMIK}search/label/Thai?&max-results=24"),
                ("Chinese", f"{PHUMIK}search/label/Chinese?&max-results=24"),
                ("Korean", f"{PHUMIK}search/label/Korea?&max-results=24")
            ]
        },
        {
            "title": "Ckh7",
            "logo": "https://www.ckh7.com/uploads/custom-logo.png",
            "action": "index_ckch7",
            "categories": [
                ("Khmer", f"{CKCH7}category.php?cat=khmer"),
                ("Thai", f"{CKCH7}category.php?cat=thai"),
                ("Chinese", f"{CKCH7}category.php?cat=chinese")
            ]
        },
        {
            "title": "FlixHQ",
            "logo": "https://img.flixhq.to/xxrz/100x100/100/bc/3c/bc3c462f0fb1b1c71288170b3bd55aeb/bc3c462f0fb1b1c71288170b3bd55aeb.png",
            "action": "index_serialgo",
            "categories": [
                ("New Movies", f"{BASE_URL}filter?type=movie&quality=all&release_year=all&genre=all&country=all"),
                ("New TV Shows", f"{BASE_URL}filter?type=tv&quality=all&release_year=all&genre=all&country=all"),
                ("Movies", f"{BASE_URL}movie"),
                ("TV Shows", f"{BASE_URL}tv-show"),
                ("Genre", "", "genre_menu"),
                ("Country", "", "country_menu"),
            ]
        },
        {
            "title": "LookMovie",
            "logo": ICON_LOOKM,
            "action": "index_lookm",
            "categories": [
                ("New Movies", f"{BASE_URL}filter?type=movie&quality=all&release_year=all&genre=all&country=all"),
                ("New TV Shows", f"{BASE_URL}filter?type=tv&quality=all&release_year=all&genre=all&country=all"),
                #("Movies", f"{BASE_URL}movie"),
                #("TV Shows", f"{BASE_URL}tv-show"),
                ("Genre", "", "genre_lmenu"),
                ("Country", "", "country_lmenu"),
            ]
        }        
    ]

    # ── Render all site headers and categories ─────────────────
    for site in sites:
        header = f"─── [COLOR red]{site['title']}[/COLOR] ───"
        addDir(header, "", site.get('action', ''), site.get('logo', ''))

        for cat in site.get('categories', []):
            label = cat[0]
            url = cat[1] if len(cat) > 1 else ""
            icon = cat[2] if len(cat) > 2 and str(cat[2]).startswith("http") else site.get('logo', '')
            action = cat[-1] if len(cat) > 2 and not str(cat[-1]).startswith("http") else site.get('action', '')
            addDir(label, url, action, icon)

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

# Search function    
def SEARCH():
    sources = [
        ("Ckh7",          lambda q: ckch7.SINDEX_CKCH7(f'{ckch7.CKCH7}search.php?keywords={quote_plus(q)}')),
        ("iDrama",        lambda q: idrama.SINDEX_IDRAMA(f'{idrama.IDRAMA}?s={quote_plus(q)}')),
        ("KhmerAvenue",   lambda q: khmerav.INDEX_GENERIC(f'{khmerav.KHMERAVENUE}?s={quote_plus(q)}', 'index_khmeravenue', label_suffix=" [COLOR yellow]KHMERAVE[/COLOR]")),
        ("Merlkon",       lambda q: khmerav.INDEX_GENERIC(f'{khmerav.MERLKON}?s={quote_plus(q)}', 'index_merlkon', label_suffix=" [COLOR cyan]MERLKON[/COLOR]")),
        ("PhumiKhmer",    lambda q: phumikhmer.SINDEX_PHUMIK(f'{phumikhmer.PHUMIK}search?q={quote_plus(q)}')),
        ("Sunday",        lambda q: sunday.SINDEX_SUNDAY(f'{sunday.SUNDAY}search?q={quote_plus(q)}')),
        ("Video4Khmer",   lambda q: video4khmer.SEARCH_VIDEO4U(q)),
        ("Vip",           lambda q: vip.SINDEX_VIP(f'{vip.VIP}?s={quote_plus(q)}')),
        ("FlixHQ",        lambda q: flixhq.INDEX_SERIALGO(f'{flixhq.BASE_URL}search/{q.strip().lower().replace(" ", "-")}', label_suffix=" [COLOR yellow]FlixHQ[/COLOR]")),
        ("LookMovie",     lambda q: lookmovie.INDEX_LOOKM(f'{lookmovie.BASE_URL}search/{q.strip().lower().replace(" ", "-")}', label_suffix=" [COLOR yellow]LookMovie[/COLOR]")),           
    ]
    dialog = xbmcgui.Dialog()
    idx = dialog.select('Search From:', [label for label, _ in sources])
    if idx == -1: return

    kb = xbmc.Keyboard('', 'Enter Search Text'); kb.doModal()
    if not kb.isConfirmed(): return
    query = kb.getText()

    try:
        sources[idx][1](query)
    except Exception as e:
        xbmcgui.Dialog().notification("Search Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        xbmc.log(f"[{ADDON_ID}] Search dispatch failed: {e}", xbmc.LOGERROR)


# KhmerTV
def KHMER_LIVETV():
    try:
        # Decode KhmerTV XML feed
        xml_data = OpenURL_KH(base64.b64decode(khmertv).decode("utf-8"))
        if isinstance(xml_data, bytes):
            xml_data = xml_data.decode("utf-8", errors="ignore")

        # Clean malformed XML
        xml_data = "\n".join(line.strip() for line in xml_data.splitlines() if line.strip())
        xml_data = re.sub(r'&(?!amp;|lt;|gt;|apos;|quot;)', '&amp;', xml_data)

        # Parse XML
        root = ET.fromstring(xml_data)
        items = root.findall(".//channel/item") or root.findall(".//item")
        if not items:
            raise Exception("No <item> found")

        xbmc.log(f"[{ADDON_ID}] Loaded {len(items)} KhmerTV channels", xbmc.LOGINFO)

        # Loop through items
        for item in items:
            title = item.findtext("title", "No Title").strip()
            url   = item.findtext("link", "").strip()
            icon  = item.findtext("thumbnail", "").strip() or ICON_KHMERTV
            resolve = item.findtext("resolve", "false").strip().lower() == "true"

            if not url:
                xbmc.log(f"[{ADDON_ID}] Missing URL for: {title}", xbmc.LOGWARNING)
                continue

            li = xbmcgui.ListItem(label=title)
            li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
            li.getVideoInfoTag().setTitle(title)
            li.setProperty('IsPlayable', 'true' if resolve else 'false')

            # use centralized playback modes
            action = "playloop" if resolve else "video_hosting"

            plugin_url = f"{sys.argv[0]}?action={action}&url={quote_plus(url)}"
            xbmcplugin.addDirectoryItem(PLUGIN_HANDLE, plugin_url, li, not resolve)

        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] KHMER_LIVETV load failed: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Error", "Failed to load Live TV feed.")


# ----- Utility Functions -----
def addLink(name, url, action, iconimage=""):
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    li = xbmcgui.ListItem(label=name)
    li.setArt({'icon': iconimage, 'poster': iconimage, 'thumb': iconimage})
    li.getVideoInfoTag().setTitle(name)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=False)

def addDir(name, url, action, iconimage=""):
    u = f"{sys.argv[0]}?url={quote_plus(str(url))}&action={quote_plus(str(action))}&name={quote_plus(str(name))}"
    li = xbmcgui.ListItem(label=name)
    if iconimage:
        li.setArt({'thumb': iconimage, 'icon': iconimage, 'poster': iconimage})
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=True)

def get_params():
    param = {}
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else sys.argv[2]
    for pair in paramstring.split('&'):
        if '=' in pair:
            key, value = pair.split('=', 1)
            param[key] = unquote_plus(value)
    return param

# ----- Parameter Parsing -----
params = get_params()
url    = params.get("url", "")
name   = params.get("name", "")
action = params.get("action", "home")

# ----- Routing -----
ROUTES = {
    # ── General & Core ───────────────────────────────
    "home":                lambda: HOME(),
    "episode_players":     lambda: EPISODE_PLAYERS(url, name),
    "play_direct":         lambda: Play_VIDEO(url),
    "playloop":            lambda: Playloop(url),
    "video_hosting":       lambda: VIDEO_HOSTING(url),
    "videolinks":          lambda: VIDEOLINKS(url),
    "khmer_livetv":        lambda: KHMER_LIVETV(),
    "search":              lambda: SEARCH(),

    # ── Video4Khmer Site ─────────────────────────────
    "index_video4u":       lambda: video4khmer.INDEX_VIDEO4U(url),
    "search_video4u":      lambda: video4khmer.SEARCH_VIDEO4U(url),
    "episode_video4khmer": lambda: video4khmer.EPISODE_VIDEO4KHMER(url),

    # ── iDrama Site (Tvsabay / OneLegend) ─────────────
    "index_idrama":        lambda: idrama.INDEX_IDRAMA(url),
    "sindex_idrama":       lambda: idrama.SINDEX_IDRAMA(url),
    "episode_tvsabay":     lambda: idrama.EPISODE_TVSABAY(url),
    "episode_onelegend":   lambda: idrama.EPISODE_ONELEGEND(url),

    # ── VIP / Craft4U Site ────────────────────────────
    "index_vip":           lambda: vip.INDEX_VIP(url),
    "sindex_vip":          lambda: vip.SINDEX_VIP(url),
    "episode_craft4u":     lambda: vip.EPISODE_CRAFT4U(url),
    "craft4u_play":        lambda: vip.PLAY_CRAFT4U(url),

    # ── CKCH7 Site ───────────────────────────────────
    "index_ckch7":         lambda: ckch7.INDEX_CKCH7(url),
    "sindex_ckch7":        lambda: ckch7.SINDEX_CKCH7(url),
    "episode_ckch7":       lambda: ckch7.EPISODE_CKCH7(url),

    # ── PhumiKhmer2 Site ─────────────────────────────
    "index_phumik":        lambda: phumikhmer.INDEX_PHUMIK(url),
    "sindex_phumik":       lambda: phumikhmer.SINDEX_PHUMIK(url),
    "episode_phumik":      lambda: phumikhmer.EPISODE_PHUMIK(url),

    # ── KhmerAvenue / Merlkon (Generic) ──────────────
    "index_khmeravenue":   lambda: khmerav.INDEX_GENERIC(url, "index_khmeravenue", "khmeravenue"),
    "index_merlkon":       lambda: khmerav.INDEX_GENERIC(url, "index_merlkon", "merlkon"),
    "index_korean":        lambda: khmerav.INDEX_GENERIC(url, "index_korean", "korean"),
    "episode_generic":     lambda: khmerav.EPISODE_GENERIC(url),

    # ── SundayDrama Site ─────────────────────────────
    "index_sunday":        lambda: sunday.INDEX_SUNDAY(url),
    "sindex_sunday":       lambda: sunday.SINDEX_SUNDAY(url),

    # ── FlixHQ Site ───────────────────────
    "genre_menu":          lambda: flixhq.GENRE_MENU(),
    "country_menu":        lambda: flixhq.COUNTRY_MENU(),
    "index_serialgo":      lambda: flixhq.INDEX_SERIALGO(url),
    "search_serialgo":     lambda: flixhq.SEARCH_SERIALGO(),
    "type":                lambda: flixhq.TYPE(url, name),
    "playloop_sg":         lambda: flixhq.PLAYLOOP_SG(url, name),
    "season":              lambda: flixhq.SEASON(url, name),
    "episode":             lambda: flixhq.EPISODE(url, name),
    "server":              lambda: flixhq.SERVER(url, name),
    "play_server":         lambda: flixhq.PLAY_SERVER(url, name),
    
    # ── LookMovie Site ───────────────────────
    "genre_lmenu":         lambda: lookmovie.GENRE_LMENU(),
    "country_lmenu":       lambda: lookmovie.COUNTRY_LMENU(),
    "index_lookm":         lambda: lookmovie.INDEX_LOOKM(url),
    "search_lookm":        lambda: lookmovie.SEARCH_LOOKM() 
}

# ────────────────────────────────────────────────
#  MAIN DISPATCHER
# ────────────────────────────────────────────────
# ----- Execute Action -----
ROUTES.get(action, lambda: HOME())()

# ----- End of Directory -----
xbmcplugin.endOfDirectory(PLUGIN_HANDLE)	