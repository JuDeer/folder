# ────────────────────────────────────────────────
#  IDRAMA SITE HANDLER
# ────────────────────────────────────────────────
import re, sys, json, xbmc, xbmcplugin, xbmcgui
from urllib.parse import urljoin, quote_plus, unquote_plus
from bs4 import BeautifulSoup

# ── Local Handlers ──────────────────────────────
from resources.lib.handlers_khmer import (
    OpenSoup as OpenSoup_KH,
    OpenURL as OpenURL_KH,
)

from resources.lib.handlers_common import USER_AGENT
from resources.lib.handlers_blogid import ADDON_ID
try:
    ADDON_ID
except NameError:
    ADDON_ID = "plugin.video.KDubbed"

# ── Kodi Plugin Handle ──────────────────────────
IDRAMA = "https://www.idramahd.com/"
PLUGIN_HANDLE = int(sys.argv[1])

############## idrama ****************** 
def INDEX_IDRAMA(url):
    _render_idrama_listing(url)

def SINDEX_IDRAMA(url):
    _render_idrama_listing(url, label_suffix=" [COLOR green]iDrama[/COLOR]", include_pagination=False)

def _render_idrama_listing(url, label_suffix="", include_pagination=True):
    soup, _ = OpenSoup_KH(url, return_html=True)
    grid = soup.select_one('div.posts-wrap.th-grid-3') or soup

    for art in grid.select('article.hitmag-post'):
        a = art.select_one('h3.entry-title a[href]')
        if not a:
            continue
        v_link, v_title = urljoin(url, a['href']), a.get_text(strip=True)

        img = art.select_one('.archive-thumb img')
        v_image = ""
        if img:
            v_image = img.get('data-src') or img.get('src') or ""
            if not v_image and img.get('srcset'):
                v_image = img['srcset'].split(',')[0].split()[0]
            if v_image:
                v_image = urljoin(url, v_image)
                v_image = re.sub(r'/s\d+(?:-[a-z]+)*/', '/s1600/', v_image)

        label = v_title + label_suffix  # suffix only shows in search
        addDir(label, v_link, "episode_players", v_image)

    if include_pagination:
        nxt = soup.find('link', rel='next')
        if nxt and nxt.get('href'):
            addDir("[B]NEXT PAGE ›[/B]", urljoin(url, nxt['href']), "index_idrama", "")

    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
 
def EPISODE_TVSABAY(start_url): # iDrama -->t.co -->tvsabay
    html = OpenURL_KH(start_url, as_text=True)
    if not html:
        xbmc.log("[KDUBBED] Failed to fetch Tvsabay page", xbmc.LOGERROR)
        return

    m = re.search(r'data-post-id=["\']?(\d+)', html)
    if not m:
        xbmc.log("[KDUBBED] No post-id found in Tvsabay page", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("No Episodes Found", "Tvsabay post-id not found.")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    post_id = m.group(1)
    xbmc.log(f"[KDUBBED] Found Tvsabay post-id: {post_id}", xbmc.LOGINFO)

    blog_id = "8016412028548971199"
    feed_url = f"https://www.blogger.com/feeds/{blog_id}/posts/default/{post_id}?alt=json"
    xbmc.log(f"[KDUBBED] Fetching Blogger feed: {feed_url}", xbmc.LOGINFO)

    json_text = OpenURL_KH(feed_url, as_text=True)
    try:
        data = json.loads(json_text)
    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to parse Tvsabay JSON: {e}", xbmc.LOGERROR)
        return

    content = data["entry"]["content"]["$t"]

    streams = re.findall(r"https?://[^\s\"']+\.m3u8", content)

    if not streams:
        xbmcgui.Dialog().ok("No Video", "No playable source found on Tvsabay.")
        return

    for idx, s in enumerate(streams, 1):
        addLink(f"Episode {idx}", s, "play_direct", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

def EPISODE_ONELEGEND(start_url):  # iDrama -->t.co -->OneLegend
    html = OpenURL_KH(start_url, as_text=True)
    if not html:
        xbmc.log("[KDUBBED] Failed to fetch OneLegend page", xbmc.LOGERROR)
        return

    m = re.search(r'data-post-id=["\']?(\d+)', html)
    if not m:
        xbmc.log("[KDUBBED] No post-id found in OneLegend page", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("No Episodes Found", "OneLegend post-id not found.")
        xbmcplugin.endOfDirectory(PLUGIN_HANDLE)
        return

    post_id = m.group(1)
    xbmc.log(f"[KDUBBED] Found OneLegend post-id: {post_id}", xbmc.LOGINFO)

    # OneLegend uses a different Blogger blog_id
    blog_id = "596013908374331296"
    feed_url = f"https://www.blogger.com/feeds/{blog_id}/posts/default/{post_id}?alt=json"
    xbmc.log(f"[KDUBBED] Fetching OneLegend Blogger feed: {feed_url}", xbmc.LOGINFO)

    json_text = OpenURL_KH(feed_url, as_text=True)
    try:
        data = json.loads(json_text)
    except Exception as e:
        xbmc.log(f"[KDUBBED] Failed to parse OneLegend JSON: {e}", xbmc.LOGERROR)
        return

    content = data["entry"]["content"]["$t"]

    streams = re.findall(r"https?://[^\s\"']+\.(?:m3u8|mp4)", content)

    if not streams:
        xbmcgui.Dialog().ok("No Video", "No playable source found on OneLegend.")
        return

    for idx, s in enumerate(streams, 1):
        addLink(f"Episode {idx}", s, "play_direct", "")
    xbmcplugin.endOfDirectory(PLUGIN_HANDLE)

# ── Shared playback handlers ────────────────────
from resources.lib.handlers_playback import (
    resolve_redirect,
    VIDEOLINKS,
    enable_inputstream_adaptive,
    Playloop,
    VIDEO_HOSTING,
    Play_VIDEO,
)

# ────────────────────────────────────────────────
#  BASIC DIRECTORY HELPERS
# ────────────────────────────────────────────────
def addDir(name, url, action, icon=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=True)

def addLink(name, url, action, icon=""):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': icon, 'icon': icon, 'poster': icon})
    li.setProperty("IsPlayable", "true")
    u = f"{sys.argv[0]}?url={quote_plus(url)}&action={quote_plus(action)}&name={quote_plus(name)}"
    xbmcplugin.addDirectoryItem(handle=PLUGIN_HANDLE, url=u, listitem=li, isFolder=False)   
